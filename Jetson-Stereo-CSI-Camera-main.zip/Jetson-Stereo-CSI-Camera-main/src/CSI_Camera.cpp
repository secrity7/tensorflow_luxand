////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2021 Mateusz Malinowski
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
////////////////////////////////////////////////////////////////////////////////

#include <opencv2/imgproc.hpp>
#include "CSI_Camera.h"

namespace
{
/**
 * Populates the string with nvarguscamerasrc command for GStreamer.
 *  @param camConfig the configuration parameters for the camera.
 *	@return the string with the command for GStreamer.
 */
std::string gstreamerPipeline(const CameraConfig& camConfig)
{
    std::string imageType = camConfig.mColour ? "BGR" : "GRAY8";
    char text[512];
    memset(text, '\0', 512);
    sprintf(text, "nvarguscamerasrc sensor-id=%u sensor-mode=%u ! video/x-raw(memory:NVMM), format=(string)NV12, framerate=(fraction)%u/1 ! "
                  "nvvidconv flip-method=%d ! video/x-raw, width=%d, height=%d, format=(string)BGRx ! videoconvert ! video/x-raw, "
                  "format=(string)%s ! appsink", camConfig.mID, camConfig.mMode, camConfig.mFramerate, camConfig.mFlip, camConfig.mImageSize.width, 
                  camConfig.mImageSize.height, imageType.c_str());
#ifdef LOG
    printf("%s\n", text);
#endif /* LOG */
    return text;
}
} /* end of the anonymous namespace */

CSI_Camera::CSI_Camera()
: ICameraTalker<CameraConfig>(),
  GenericThread<CSI_Camera>(),
  mID(0),
  mImgSize(),
  mColour(true),
  mCapture(),
  mNumberOfFrames()
{
}

CSI_Camera::~CSI_Camera()
{
	stopCamera();
}

bool CSI_Camera::startCamera(const CameraConfig& camConfig)
{
    if (isInitialised())
    {
        stopCamera();
    }
	mID = camConfig.mID;
    mImgSize = camConfig.mImageSize;
    mColour = camConfig.mColour;
    if (camConfig.mOfflineImages.empty())
    {
	    mCapture.open(gstreamerPipeline(camConfig), cv::CAP_GSTREAMER);
    }
    else
    {
        if (mCapture.open(camConfig.mOfflineImages, cv::CAP_IMAGES))
        {
            printf("Succcessfully opened: %s \n", camConfig.mOfflineImages.c_str());
            mNumberOfFrames = static_cast<int>(mCapture.get(cv::CAP_PROP_FRAME_COUNT));
        }
    }
    return (isInitialised() && startThread());
}

void CSI_Camera::stopCamera()
{
    stopThread();
    if (mCapture.isOpened())
    {
    	mCapture.release();
    }
}

bool CSI_Camera::isInitialised() const
{
    return mCapture.isOpened();
}

uint8_t CSI_Camera::getSizeForMode(const uint8_t mode, cv::Size& size)
{
    switch (mode)
    {
        case 0:
            size = cv::Size(3264, 2464);
            return 21;
        case 1:
            size = cv::Size(3264, 1848);
            return 28;
        case 2:
            size = cv::Size(1920, 1080);
            return 30;
        case 3:
            size = cv::Size(1640, 1232);
            return 30;
        case 4:
            size = cv::Size(1280,  720);
            return 60;
        case 5:
            size = cv::Size(1280,  720);
            return 120;
        default:
            size = cv::Size(0, 0);
            return 0;
    }
}

void* CSI_Camera::threadBody()
{
    CameraData camData;
    camData.mID.push_back(getId());
    camData.mTimestamp.push_back(-1.0);
    camData.mImage.push_back(cv::cuda::HostMem(getSize(), getColour() ? CV_8UC3 : CV_8UC1, cv::cuda::HostMem::AllocType::SHARED));
    
    // this routine is for when we read images from the actual camera
    if (0 == mNumberOfFrames)
    {
        while (isRunning())
        {
            if (mCapture.read(camData.mImage[0]))
            {
                camData.mTimestamp[0] = mCapture.get(cv::CAP_PROP_POS_MSEC);
                notifyListeners(camData);           
            }
        }
    }
    // here when we read images from files
    else
    {
        int numberOfFrames = 0;
        cv::Mat tempImgCol;
        cv::Mat tempImgGrey;
        while (isRunning())
        {
            if (mCapture.read(tempImgCol))
            {
                camData.mTimestamp[0] = static_cast<double>(numberOfFrames);
                // if we are loading images from files and we loaded the last one, reset counter to zero to loop again indefinitely.
                if (++numberOfFrames == mNumberOfFrames)
                {
                    numberOfFrames = 0;
                    mCapture.set(cv::CAP_PROP_POS_FRAMES, 0);
                } 
                if (!getColour() && tempImgCol.channels() == 3)
                {
                    // an image by default could be read as BGR. If this happens and we wanted greyscale images, we need to convert it.
                    cv::cvtColor(tempImgCol, tempImgGrey, cv::COLOR_BGR2GRAY, 1);
                    cv::resize(tempImgGrey, camData.mImage[0], getSize());
                }
                else
                {
                    cv::resize(tempImgCol, camData.mImage[0], getSize());
                }
                notifyListeners(camData);           
            }
        }
    }
    return nullptr;
}
