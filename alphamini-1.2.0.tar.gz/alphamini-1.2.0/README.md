﻿# AlphaMini PythonSDK
Documents: <br/>
[Chinese](http://docs.ubtrobot.com/alphamini/python-sdk/index.html)
<br/>
[English](http://docs.ubtrobot.com/alphamini/python-sdk-en/index.html)